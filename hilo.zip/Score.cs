class Score {
    public int CurrentScore;

    public Score(int defaultScore) {
        CurrentScore = defaultScore;
    }
}
