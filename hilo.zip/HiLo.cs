﻿class HiLo {
    static void Main(string[] args) {
        var game = new Game();
        game.Play();
    }
}